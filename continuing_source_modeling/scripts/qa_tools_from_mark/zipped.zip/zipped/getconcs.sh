perl scripts/zplot2profile-100D.pl 100-D-56-2/input 100-D-56-2/plot.49478 1 1 cr6-concs
perl scripts/build-ics-100D.pl cr6-concs-2126.csv 18 1.0 100D-2026-ics.dat 
